function inquiry() {
    confirm("You have successfully submitted your inquiry. We will get back to you as soon as possible.");
    return true;
}