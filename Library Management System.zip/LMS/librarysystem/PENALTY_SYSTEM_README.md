# Library Management System - Penalty System

## Overview
This Django project now includes a comprehensive penalty system for late book returns. The system automatically calculates penalties when users return books after the grace period and provides a complete interface for managing penalties.

## Features Implemented

### 1. Penalty Calculation
- **Grace Period**: 3 days after book issue
- **Penalty Rate**: ₹50 per day after grace period
- **Automatic Calculation**: Penalties are calculated automatically when books are returned

### 2. Database Models

#### Updated IssuedBook Model
- Added `return_date` field to track when books are returned
- Added `calculate_penalty()` method for penalty calculation

#### New Penalty Model
- `user`: ForeignKey to UserProfile
- `book`: ForeignKey to Book
- `issued_book`: ForeignKey to IssuedBook
- `fine_amount`: DecimalField for penalty amount
- `days_overdue`: IntegerField for days overdue
- `created_at`: DateTimeField for penalty creation date
- `is_paid`: BooleanField for payment status

### 3. Views and URLs

#### New Views
- `penalty_list`: Display user's penalty history with statistics
- `pay_penalty`: Mark penalties as paid
- Updated `return_book_confirm`: Enhanced with penalty calculation and display

#### New URLs
- `/penalties/`: View penalty list
- `/penalties/<id>/pay/`: Pay specific penalty

### 4. Templates

#### Updated Templates
- `return_book_confirm.html`: Shows penalty information before return
- `return_book.html`: Shows potential penalties for overdue books

#### New Templates
- `penalty_list.html`: Complete penalty management interface
- `pay_penalty.html`: Penalty payment confirmation

### 5. Custom Template Filters
- `timesince_days`: Calculate days since a datetime
- `calculate_penalty`: Calculate penalty amount based on days overdue

## How It Works

### Book Return Process
1. User clicks "Return" on an issued book
2. System calculates potential penalty (if overdue)
3. User sees penalty warning and amount before confirming
4. Upon confirmation, penalty is automatically created and recorded
5. Book is removed from issued books list

### Penalty Management
1. Users can view all their penalties via "Penalties" button
2. Statistics show total penalties, amounts, and payment status
3. Users can mark penalties as paid
4. Complete history is maintained

### Penalty Calculation Logic
```python
# Example: Book issued 5 days ago
days_overdue = (return_date - issue_date).days - 3
# days_overdue = 5 - 3 = 2 days
penalty_amount = days_overdue * 50
# penalty_amount = 2 * 50 = ₹100
```

## User Interface Features

### Navigation
- Added "Penalties" button to main navigation
- Easy access to penalty management

### Visual Indicators
- ⚠️ Warning icons for overdue books
- Color-coded penalty amounts (red for unpaid)
- Clear payment status indicators

### Statistics Dashboard
- Total penalties count
- Total amount owed
- Paid vs unpaid counts
- Detailed penalty history table

## Database Migration
- Migration `0011_add_penalty_system.py` adds new models and fields
- Backward compatible with existing data

## Testing
- Management command `test_penalty` available for testing
- Creates sample data to verify penalty calculations
- Run with: `python manage.py test_penalty`

## Admin Interface
- Penalty model registered in Django admin
- Full CRUD operations available for administrators
- Easy management of penalty records

## Security Features
- User-specific penalty views (users can only see their own penalties)
- Login required for all penalty operations
- CSRF protection on all forms

## Future Enhancements
- Email notifications for overdue books
- Automatic penalty reminders
- Payment gateway integration
- Penalty waiver system for special cases
- Detailed reporting for administrators

## Usage Instructions

### For Users
1. **Returning Books**: Navigate to "Return Book" and click return
2. **Viewing Penalties**: Click "Penalties" in navigation
3. **Paying Penalties**: Click "Pay Now" on unpaid penalties
4. **Checking Status**: View payment status in penalty list

### For Administrators
1. **View All Penalties**: Access via Django admin
2. **Manage Penalties**: Edit, delete, or mark as paid
3. **Generate Reports**: Use admin interface for reporting

## Technical Details

### Dependencies
- Django 3.2+ (for template filters and model features)
- Python 3.7+ (for datetime operations)

### File Structure
```
account/
├── models.py (updated with Penalty model)
├── views.py (updated with penalty views)
├── urls.py (updated with penalty URLs)
├── admin.py (updated with Penalty registration)
├── templatetags/
│   └── penalty_filters.py (custom template filters)
├── management/
│   └── commands/
│       └── test_penalty.py (testing command)
└── migrations/
    └── 0011_add_penalty_system.py (database migration)

templates/account/
├── penalty_list.html (new)
├── pay_penalty.html (new)
├── return_book_confirm.html (updated)
├── return_book.html (updated)
└── base.html (updated with navigation)
```

This penalty system provides a complete solution for managing late book returns with automatic calculation, user-friendly interface, and comprehensive tracking capabilities. 