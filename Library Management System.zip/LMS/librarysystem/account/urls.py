from django.urls import path
from . import views

urlpatterns = [
    path('', views.login_view, name='login'),       
    path('login/', views.login_view, name='login'), 
    path('signup/', views.signup_view, name='signup'),
    path('logout/', views.logout_view, name='logout'),
    path('home/', views.home, name='home'),          
    path('category/<int:category_id>/', views.category_detail, name='category_detail'),
    path('issue-book/', views.issue_book, name='issue_book'),
    path('issue-book/<int:book_id>/', views.issue_book_confirm, name='issue_book_confirm'),
    path('return-book/', views.return_book, name='return_book'),
    path('return-book/<int:issue_id>/confirm/', views.return_book_confirm, name='return_book_confirm'),
    path('penalties/', views.penalty_list, name='penalty_list'),
    path('penalties/<int:penalty_id>/pay/', views.pay_penalty, name='pay_penalty'),
    path('history/', views.history, name='history'),
]
