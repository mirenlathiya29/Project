from django.core.management.base import BaseCommand
from django.utils import timezone
from datetime import timedelta
from account.models import UserProfile, Book, History, Category

class Command(BaseCommand):
    help = 'Create sample history data for testing'

    def handle(self, *args, **options):
        # Get or create a test user
        user, created = UserProfile.objects.get_or_create(
            username='testuser',
            defaults={
                'email': 'test@example.com',
                'password': 'testpass123'
            }
        )
        
        if created:
            self.stdout.write(self.style.SUCCESS(f'Created test user: {user.username}'))
        
        # Get some books
        books = Book.objects.all()[:5]  # Get first 5 books
        
        if not books:
            self.stdout.write(self.style.ERROR('No books found. Please create some books first.'))
            return
        
        # Create sample history entries
        history_entries = []
        
        for i, book in enumerate(books):
            # Create different scenarios
            if i == 0:
                # On time return
                issue_date = timezone.now() - timedelta(days=5)
                return_date = issue_date + timedelta(days=2)
                had_penalty = False
                penalty_amount = 0
            elif i == 1:
                # Late return with penalty
                issue_date = timezone.now() - timedelta(days=10)
                return_date = issue_date + timedelta(days=7)
                had_penalty = True
                penalty_amount = 200  # 4 days overdue * 50
            elif i == 2:
                # Very late return
                issue_date = timezone.now() - timedelta(days=15)
                return_date = issue_date + timedelta(days=12)
                had_penalty = True
                penalty_amount = 450  # 9 days overdue * 50
            else:
                # Normal return
                issue_date = timezone.now() - timedelta(days=8)
                return_date = issue_date + timedelta(days=3)
                had_penalty = False
                penalty_amount = 0
            
            days_borrowed = (return_date - issue_date).days
            
            history = History.objects.create(
                user=user,
                book=book,
                issue_date=issue_date,
                return_date=return_date,
                days_borrowed=days_borrowed,
                had_penalty=had_penalty,
                penalty_amount=penalty_amount
            )
            history_entries.append(history)
        
        self.stdout.write(
            self.style.SUCCESS(
                f'Successfully created {len(history_entries)} history entries for user {user.username}'
            )
        )
        
        # Show summary
        total_books = len(history_entries)
        total_days = sum(h.days_borrowed for h in history_entries)
        books_with_penalties = sum(1 for h in history_entries if h.had_penalty)
        total_penalty = sum(h.penalty_amount for h in history_entries)
        
        self.stdout.write(f'Total books: {total_books}')
        self.stdout.write(f'Total days: {total_days}')
        self.stdout.write(f'Books with penalties: {books_with_penalties}')
        self.stdout.write(f'Total penalty amount: ₹{total_penalty}')
