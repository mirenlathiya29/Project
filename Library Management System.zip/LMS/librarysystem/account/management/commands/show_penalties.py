from django.core.management.base import BaseCommand
from account.models import UserProfile, Penalty

class Command(BaseCommand):
    help = 'Show all penalties in the database'

    def handle(self, *args, **options):
        self.stdout.write('Current penalties in database:')
        
        try:
            penalties = Penalty.objects.all().order_by('-created_at')
            
            if penalties.count() == 0:
                self.stdout.write('No penalties found in database.')
                return
            
            for penalty in penalties:
                self.stdout.write(f'ID: {penalty.id}')
                self.stdout.write(f'  User: {penalty.user.username}')
                self.stdout.write(f'  Book: {penalty.book.title}')
                self.stdout.write(f'  Amount: ₹{penalty.fine_amount}')
                self.stdout.write(f'  Days Overdue: {penalty.days_overdue}')
                self.stdout.write(f'  Is Paid: {penalty.is_paid}')
                self.stdout.write(f'  Created: {penalty.created_at}')
                self.stdout.write(f'  Issued Book ID: {penalty.issued_book_id if penalty.issued_book else "None"}')
                self.stdout.write('---')
            
            # Show summary
            total_penalties = penalties.count()
            total_amount = sum(p.fine_amount for p in penalties)
            paid_count = penalties.filter(is_paid=True).count()
            unpaid_count = penalties.filter(is_paid=False).count()
            
            self.stdout.write(f'\nSummary:')
            self.stdout.write(f'  Total Penalties: {total_penalties}')
            self.stdout.write(f'  Total Amount: ₹{total_amount}')
            self.stdout.write(f'  Paid: {paid_count}')
            self.stdout.write(f'  Unpaid: {unpaid_count}')
            
        except Exception as e:
            self.stdout.write(self.style.ERROR(f'Error showing penalties: {e}')) 