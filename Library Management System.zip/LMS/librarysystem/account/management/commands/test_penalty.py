from django.core.management.base import BaseCommand
from django.utils import timezone
from account.models import UserProfile, Book, Category, IssuedBook, Penalty
from datetime import timedelta

class Command(BaseCommand):
    help = 'Test the penalty system by creating sample data'

    def handle(self, *args, **options):
        self.stdout.write('Testing penalty system...')
        
        # Create test data if it doesn't exist
        try:
            # Create a test user
            user, created = UserProfile.objects.get_or_create(
                username='testuser',
                defaults={'email': 'test@example.com', 'password': 'testpass'}
            )
            if created:
                self.stdout.write('Created test user: testuser')
            
            # Create a test category
            category, created = Category.objects.get_or_create(
                title='Test Category',
                defaults={'description': 'Test category for penalty testing'}
            )
            if created:
                self.stdout.write('Created test category')
            
            # Create a test book
            book, created = Book.objects.get_or_create(
                title='Test Book',
                defaults={'author': 'Test Author', 'category': category}
            )
            if created:
                self.stdout.write('Created test book')
            
            # Create an issued book that's overdue (issued 5 days ago)
            issue_date = timezone.now() - timedelta(days=5)
            issued_book, created = IssuedBook.objects.get_or_create(
                user=user,
                book=book,
                defaults={'issue_date': issue_date}
            )
            if created:
                self.stdout.write('Created overdue issued book (5 days ago)')
            
            # Test penalty calculation
            days_overdue = (timezone.now() - issued_book.issue_date).days - 3
            penalty_amount = days_overdue * 50 if days_overdue > 0 else 0
            
            self.stdout.write(f'Days overdue: {days_overdue}')
            self.stdout.write(f'Penalty amount: ₹{penalty_amount}')
            
            # Create a penalty record
            penalty, created = Penalty.objects.get_or_create(
                user=user,
                book=book,
                issued_book=issued_book,
                defaults={
                    'fine_amount': penalty_amount,
                    'days_overdue': days_overdue
                }
            )
            if created:
                self.stdout.write('Created penalty record')
            
            self.stdout.write(self.style.SUCCESS('Penalty system test completed successfully!'))
            
        except Exception as e:
            self.stdout.write(self.style.ERROR(f'Error testing penalty system: {e}')) 