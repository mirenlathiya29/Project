from django.core.management.base import BaseCommand
from django.utils import timezone
from account.models import UserProfile, Book, Category, IssuedBook, Penalty
from datetime import timedelta

class Command(BaseCommand):
    help = 'Test late book return and penalty creation'

    def handle(self, *args, **options):
        self.stdout.write('Testing late book return and penalty creation...')
        
        try:
            # Get or create test user
            user, created = UserProfile.objects.get_or_create(
                username='demo_user',
                defaults={'email': 'demo@example.com', 'password': 'demo123'}
            )
            
            # Get or create test book
            category, created = Category.objects.get_or_create(
                title='Test Category',
                defaults={'description': 'Test category'}
            )
            
            book, created = Book.objects.get_or_create(
                title='Test Book for Late Return',
                defaults={'author': 'Test Author', 'category': category}
            )
            
            # Create an issued book that's overdue (issued 5 days ago)
            issue_date = timezone.now() - timedelta(days=5)
            issued_book, created = IssuedBook.objects.get_or_create(
                user=user,
                book=book,
                defaults={'issue_date': issue_date}
            )
            
            if created:
                self.stdout.write(f'Created issued book: {book.title} (issued 5 days ago)')
            
            # Simulate return process
            self.stdout.write('Simulating book return...')
            
            # Set return date
            issued_book.return_date = timezone.now()
            issued_book.save()
            
            # Calculate penalty
            days_overdue = (issued_book.return_date - issued_book.issue_date).days - 3
            penalty_amount = days_overdue * 50 if days_overdue > 0 else 0
            
            self.stdout.write(f'Days overdue: {days_overdue}')
            self.stdout.write(f'Penalty amount: ₹{penalty_amount}')
            
            if days_overdue > 0:
                # Create penalty record
                penalty = Penalty.objects.create(
                    user=user,
                    book=book,
                    issued_book=issued_book,
                    fine_amount=penalty_amount,
                    days_overdue=days_overdue
                )
                
                self.stdout.write(f'Created penalty record: {penalty}')
                
                # Delete issued book (penalty should persist)
                issued_book.delete()
                self.stdout.write('Deleted issued book record')
                
                # Check if penalty still exists
                penalty_check = Penalty.objects.filter(id=penalty.id).first()
                if penalty_check:
                    self.stdout.write(self.style.SUCCESS('✅ Penalty record persisted after issued book deletion!'))
                else:
                    self.stdout.write(self.style.ERROR('❌ Penalty record was deleted with issued book!'))
                
                # Show all penalties for user
                all_penalties = Penalty.objects.filter(user=user)
                self.stdout.write(f'Total penalties for user: {all_penalties.count()}')
                for p in all_penalties:
                    self.stdout.write(f'  - {p.book.title}: ₹{p.fine_amount} ({p.days_overdue} days overdue)')
            else:
                self.stdout.write('No penalty - book returned on time')
            
            self.stdout.write(self.style.SUCCESS('Late return test completed successfully!'))
            
        except Exception as e:
            self.stdout.write(self.style.ERROR(f'Error testing late return: {e}')) 