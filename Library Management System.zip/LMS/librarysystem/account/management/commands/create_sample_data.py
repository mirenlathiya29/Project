from django.core.management.base import BaseCommand
from account.models import Category, Book, UserProfile
from django.core.files.base import ContentFile
import os

class Command(BaseCommand):
    help = 'Create sample data for the library system'

    def handle(self, *args, **options):
        self.stdout.write('Creating sample data...')
        
        try:
            # Create sample categories
            categories_data = [
                {
                    'title': 'Fiction',
                    'description': 'Explore the world of imagination with our fiction collection.'
                },
                {
                    'title': 'Non-Fiction',
                    'description': 'Discover real-world knowledge and facts.'
                },
                {
                    'title': 'Science & Technology',
                    'description': 'Stay updated with the latest in science and technology.'
                },
                {
                    'title': 'History',
                    'description': 'Journey through time with our historical collection.'
                }
            ]
            
            for cat_data in categories_data:
                category, created = Category.objects.get_or_create(
                    title=cat_data['title'],
                    defaults={'description': cat_data['description']}
                )
                if created:
                    self.stdout.write(f'Created category: {category.title}')
            
            # Create sample books
            books_data = [
                {
                    'title': 'The Great Gatsby',
                    'author': 'F. Scott Fitzgerald',
                    'category_title': 'Fiction'
                },
                {
                    'title': 'To Kill a Mockingbird',
                    'author': 'Harper Lee',
                    'category_title': 'Fiction'
                },
                {
                    'title': '1984',
                    'author': 'George Orwell',
                    'category_title': 'Fiction'
                },
                {
                    'title': 'The Art of War',
                    'author': 'Sun Tzu',
                    'category_title': 'Non-Fiction'
                },
                {
                    'title': 'Sapiens',
                    'author': 'Yuval Noah Harari',
                    'category_title': 'Non-Fiction'
                },
                {
                    'title': 'The Selfish Gene',
                    'author': 'Richard Dawkins',
                    'category_title': 'Science & Technology'
                },
                {
                    'title': 'A Brief History of Time',
                    'author': 'Stephen Hawking',
                    'category_title': 'Science & Technology'
                },
                {
                    'title': 'The Guns of August',
                    'author': 'Barbara W. Tuchman',
                    'category_title': 'History'
                }
            ]
            
            for book_data in books_data:
                category = Category.objects.get(title=book_data['category_title'])
                book, created = Book.objects.get_or_create(
                    title=book_data['title'],
                    defaults={
                        'author': book_data['author'],
                        'category': category
                    }
                )
                if created:
                    self.stdout.write(f'Created book: {book.title} by {book.author}')
            
            # Create a sample user
            user, created = UserProfile.objects.get_or_create(
                username='demo_user',
                defaults={
                    'email': 'demo@example.com',
                    'password': 'demo123'
                }
            )
            if created:
                self.stdout.write('Created demo user: demo_user')
            
            self.stdout.write(self.style.SUCCESS('Sample data created successfully!'))
            self.stdout.write('You can now log in with username: demo_user and password: demo123')
            
        except Exception as e:
            self.stdout.write(self.style.ERROR(f'Error creating sample data: {e}')) 