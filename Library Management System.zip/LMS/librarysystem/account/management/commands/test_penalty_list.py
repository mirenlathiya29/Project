from django.core.management.base import BaseCommand
from account.models import UserProfile, Penalty
from django.test import RequestFactory
from account.views import penalty_list
from django.contrib.messages.storage.fallback import FallbackStorage

class Command(BaseCommand):
    help = 'Test penalty list view functionality'

    def handle(self, *args, **options):
        self.stdout.write('Testing penalty list view...')
        
        try:
            # Get demo user
            user = UserProfile.objects.get(username='demo_user')
            
            # Create a mock request
            factory = RequestFactory()
            request = factory.get('/penalties/')
            
            # Set up session
            request.session = {}
            request.session['username'] = user.username
            
            # Set up messages
            setattr(request, 'session', {})
            messages = FallbackStorage(request)
            setattr(request, '_messages', messages)
            
            # Call the view
            response = penalty_list(request)
            
            self.stdout.write(f'Response status: {response.status_code}')
            
            if response.status_code == 200:
                self.stdout.write(self.style.SUCCESS('✅ Penalty list view is working!'))
                
                # Check if penalties are in context
                if hasattr(response, 'context_data'):
                    penalties = response.context_data.get('penalties', [])
                    total_amount = response.context_data.get('total_amount', 0)
                    paid_count = response.context_data.get('paid_count', 0)
                    unpaid_count = response.context_data.get('unpaid_count', 0)
                    
                    self.stdout.write(f'Penalties in context: {len(penalties)}')
                    self.stdout.write(f'Total amount: ₹{total_amount}')
                    self.stdout.write(f'Paid: {paid_count}, Unpaid: {unpaid_count}')
                else:
                    self.stdout.write('No context data found')
            else:
                self.stdout.write(self.style.ERROR(f'❌ Penalty list view returned status {response.status_code}'))
            
            # Also test direct database query
            penalties = Penalty.objects.filter(user=user)
            self.stdout.write(f'Direct DB query - Penalties for {user.username}: {penalties.count()}')
            for penalty in penalties:
                self.stdout.write(f'  - {penalty.book.title}: ₹{penalty.fine_amount} ({penalty.days_overdue} days)')
            
        except Exception as e:
            self.stdout.write(self.style.ERROR(f'Error testing penalty list: {e}')) 