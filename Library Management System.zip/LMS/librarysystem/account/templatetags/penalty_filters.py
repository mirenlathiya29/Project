from django import template
from django.utils import timezone
from datetime import timedelta

register = template.Library()

@register.filter
def timesince_days(value):
    """Calculate the number of days since a datetime value"""
    if not value:
        return 0
    
    now = timezone.now()
    if value.tzinfo is None:
        value = timezone.make_aware(value)
    
    delta = now - value
    return delta.days

@register.filter
def calculate_penalty(days_overdue):
    """Calculate penalty amount based on days overdue"""
    if days_overdue > 3:
        return (days_overdue - 3) * 50
    return 0 