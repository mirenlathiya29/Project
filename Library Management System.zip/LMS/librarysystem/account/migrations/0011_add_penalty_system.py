# Generated manually for penalty system

from django.db import migrations, models
import django.db.models.deletion
import django.utils.timezone


class Migration(migrations.Migration):

    dependencies = [
        ('account', '0010_alter_issuedbook_issue_date_alter_issuedbook_user'),
    ]

    operations = [
        migrations.AddField(
            model_name='issuedbook',
            name='return_date',
            field=models.DateTimeField(blank=True, null=True),
        ),
        migrations.CreateModel(
            name='Penalty',
            fields=[
                ('id', models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('fine_amount', models.DecimalField(decimal_places=2, max_digits=10)),
                ('days_overdue', models.IntegerField()),
                ('created_at', models.DateTimeField(auto_now_add=True)),
                ('is_paid', models.BooleanField(default=False)),
                ('book', models.ForeignKey(on_delete=django.db.models.deletion.CASCADE, to='account.book')),
                ('issued_book', models.ForeignKey(on_delete=django.db.models.deletion.CASCADE, to='account.issuedbook')),
                ('user', models.ForeignKey(on_delete=django.db.models.deletion.CASCADE, to='account.userprofile')),
            ],
        ),
    ] 