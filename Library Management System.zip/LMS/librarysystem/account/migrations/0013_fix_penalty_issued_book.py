# Generated manually to fix penalty issued_book field

from django.db import migrations, models
import django.db.models.deletion


class Migration(migrations.Migration):

    dependencies = [
        ('account', '0012_make_images_optional'),
    ]

    operations = [
        migrations.AlterField(
            model_name='penalty',
            name='issued_book',
            field=models.ForeignKey(blank=True, null=True, on_delete=django.db.models.deletion.SET_NULL, to='account.issuedbook'),
        ),
    ] 