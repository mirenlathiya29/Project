# Generated manually to make image fields optional

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('account', '0011_add_penalty_system'),
    ]

    operations = [
        migrations.AlterField(
            model_name='book',
            name='image',
            field=models.ImageField(blank=True, null=True, upload_to='book_images/'),
        ),
        migrations.AlterField(
            model_name='category',
            name='image',
            field=models.ImageField(blank=True, null=True, upload_to='category_images/'),
        ),
    ] 