from django.contrib import admin
from .models import UserProfile , Category , Book , IssuedBook, Penalty, History

admin.site.register(UserProfile)
admin.site.register(Category)
admin.site.register(Book)
admin.site.register(IssuedBook)
admin.site.register(Penalty)
admin.site.register(History)