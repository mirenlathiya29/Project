from django.db import models
from django.contrib.auth.models import User
from django.utils import timezone
from datetime import timedelta

class UserProfile(models.Model):
    username = models.CharField(max_length=150, unique=True)
    email = models.EmailField(unique=True)
    password = models.CharField(max_length=128)

    def __str__(self):
        return self.username
    
class Category(models.Model):
    title = models.CharField(max_length=100)
    image = models.ImageField(upload_to='category_images/', null=True, blank=True)
    description = models.TextField()

    def __str__(self):
        return self.title   
   
class Book(models.Model):
    title = models.CharField(max_length=100)
    author = models.CharField(max_length=100)
    image = models.ImageField(upload_to='book_images/', null=True, blank=True)
    category = models.ForeignKey(Category, on_delete=models.CASCADE, related_name="books")  

    def __str__(self):
        return self.title    
    
class IssuedBook(models.Model):
    user = models.ForeignKey(UserProfile, on_delete=models.CASCADE)
    book = models.ForeignKey(Book, on_delete=models.CASCADE)
    issue_date = models.DateTimeField()
    return_date = models.DateTimeField(null=True, blank=True)
    
    def __str__(self):
        return f"{self.user.username} - {self.book.title}"
    
    def calculate_penalty(self):
        """Calculate penalty amount if book is returned late"""
        if not self.return_date:
            return 0
        
        # Calculate days overdue (3 days grace period)
        days_overdue = (self.return_date - self.issue_date).days - 3
        
        if days_overdue > 0:
            return days_overdue * 50  # 50 rupees per day
        return 0

class Penalty(models.Model):
    user = models.ForeignKey(UserProfile, on_delete=models.CASCADE)
    book = models.ForeignKey(Book, on_delete=models.CASCADE)
    issued_book = models.ForeignKey(IssuedBook, on_delete=models.SET_NULL, null=True, blank=True)
    fine_amount = models.DecimalField(max_digits=10, decimal_places=2)
    days_overdue = models.IntegerField()
    created_at = models.DateTimeField(auto_now_add=True)
    is_paid = models.BooleanField(default=False)
    
    def __str__(self):
        return f"{self.user.username} - {self.book.title} - ₹{self.fine_amount}"

class History(models.Model):
    user = models.ForeignKey(UserProfile, on_delete=models.CASCADE)
    book = models.ForeignKey(Book, on_delete=models.CASCADE)
    issue_date = models.DateTimeField()
    return_date = models.DateTimeField()
    days_borrowed = models.IntegerField()
    had_penalty = models.BooleanField(default=False)
    penalty_amount = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    created_at = models.DateTimeField(auto_now_add=True)
    
    def __str__(self):
        return f"{self.user.username} - {self.book.title} ({self.issue_date.date()} to {self.return_date.date()})"
    
    class Meta:
        verbose_name_plural = "Histories"
        ordering = ['-return_date']
    