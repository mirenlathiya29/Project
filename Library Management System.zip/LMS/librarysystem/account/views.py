from django.shortcuts import render, get_object_or_404, redirect
from .models import Book, Category, IssuedBook, UserProfile, Penalty, History
from django.db.models import Q
from django.utils import timezone
from functools import wraps
from django.contrib import messages
from datetime import timedelta


def signup_view(request):
    if request.method == 'POST':
        username = request.POST['username']
        email = request.POST['email']
        password = request.POST['password']
        confirm = request.POST['confirm']

        if password != confirm:
            messages.error(request, "Passwords do not match")
            return redirect('signup')

        if UserProfile.objects.filter(username=username).exists():
            messages.error(request, "Username already exists")
            return redirect('signup')
        if UserProfile.objects.filter(email=email).exists():
            messages.error(request, "Email already registered")
            return redirect('signup')

        UserProfile.objects.create(username=username, email=email, password=password)
        messages.success(request, "Account created successfully! Please login.")
        return redirect('home')

    return render(request, 'account/signup.html')


def login_view(request):
    if 'username' in request.session:
        return redirect('home')  # already logged in

    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']

        try:
            user = UserProfile.objects.get(username=username, password=password)
            request.session['username'] = user.username
            return redirect('home')
        except UserProfile.DoesNotExist:
            messages.error(request, 'Invalid username or password.')

    return render(request, 'account/login.html')


def logout_view(request):
    if 'username' in request.session:
        del request.session['username']
    messages.success(request, 'Logged out successfully.')
    return redirect('login')


def login_required_custom(view_func):
    @wraps(view_func)
    def _wrapped_view(request, *args, **kwargs):
        if 'username' not in request.session:
            return redirect('login')
        return view_func(request, *args, **kwargs)
    return _wrapped_view


def get_logged_in_user(request):
    username = request.session.get('username')
    if not username:
        return None
    try:
        return UserProfile.objects.get(username=username)
    except UserProfile.DoesNotExist:
        return None


@login_required_custom
def home(request):
    user = get_logged_in_user(request)
    if not user:
        return redirect('login')

    categories = Category.objects.all()
    return render(request, 'account/home.html', {
        'categories': categories,
        'user': user,
    })


@login_required_custom
def category_detail(request, category_id):
    user = get_logged_in_user(request)
    if not user:
        return redirect('login')

    category = get_object_or_404(Category, id=category_id)
    top_books = category.books.all()[:5]
    return render(request, 'account/category_detail.html', {
        'category': category,
        'top_books': top_books,
        'user': user,
    })


@login_required_custom
def issue_book(request):
    user = get_logged_in_user(request)
    if not user:
        return redirect('login')

    query = request.GET.get('q')
    books = Book.objects.all()
    if query:
        books = books.filter(Q(title__icontains=query) | Q(author__icontains=query))

    issued_books = IssuedBook.objects.filter(user=user).values_list('book_id', flat=True)
    return render(request, 'account/issue_book.html', {
        'books': books,
        'issued_books': issued_books,
        'user': user,
        'query': query,
    })


@login_required_custom
def issue_book_confirm(request, book_id):
    user = get_logged_in_user(request)
    if not user:
        messages.error(request, "Please log in to issue books.")
        return redirect('login')

    book = get_object_or_404(Book, id=book_id)

    already_issued = IssuedBook.objects.filter(user=user, book=book).exists()

    if request.method == 'POST':
        if already_issued:
            messages.warning(request, f"You have already issued '{book.title}'.")
            return redirect('issue_book')

        try:
            IssuedBook.objects.create(
                user=user,
                book=book,
                issue_date=timezone.now()
            )
            messages.success(request, f"You have successfully issued '{book.title}'.")
        except Exception as e:
            messages.error(request, f"Error issuing book: {str(e)}")

        return redirect('issue_book')

    return render(request, 'account/issue_book_confirm.html', {
        'book': book,
        'already_issued': already_issued,
        'user': user,
    })

@login_required_custom
def return_book(request):
    user = get_logged_in_user(request)
    if not user:
        return redirect('login')

    issued_books = IssuedBook.objects.filter(user=user)

    return render(request, 'account/return_book.html', {
        'issued_books': issued_books,
        'user': user,
    })


@login_required_custom
def return_book_confirm(request, issue_id):
    user = get_logged_in_user(request)
    if not user:
        return redirect('login')

    issued_book = get_object_or_404(IssuedBook, id=issue_id, user=user)
    
    # Calculate penalty if book is being returned
    penalty_amount = 0
    days_overdue = 0
    
    if request.method == 'POST':
        # Set return date
        issued_book.return_date = timezone.now()
        issued_book.save()
        
        # Calculate penalty
        days_overdue = (issued_book.return_date - issued_book.issue_date).days - 3
        penalty_amount = 0
        had_penalty = False
        
        if days_overdue > 0:
            penalty_amount = days_overdue * 50  # 50 rupees per day
            had_penalty = True
            
            # Create penalty record BEFORE deleting issued_book
            penalty = Penalty.objects.create(
                user=user,
                book=issued_book.book,
                issued_book=issued_book,
                fine_amount=penalty_amount,
                days_overdue=days_overdue
            )
            
            messages.warning(request, f"Book returned late! Penalty: ₹{penalty_amount} for {days_overdue} days overdue.")
        else:
            messages.success(request, f"You have successfully returned '{issued_book.book.title}' on time.")
        
        # Create history record BEFORE deleting issued_book
        days_borrowed = (issued_book.return_date - issued_book.issue_date).days
        History.objects.create(
            user=user,
            book=issued_book.book,
            issue_date=issued_book.issue_date,
            return_date=issued_book.return_date,
            days_borrowed=days_borrowed,
            had_penalty=had_penalty,
            penalty_amount=penalty_amount
        )
        
        # Delete the issued book record AFTER creating history and penalty
        issued_book.delete()
        return redirect('return_book')

    # Calculate potential penalty for display
    if not issued_book.return_date:
        days_overdue = (timezone.now() - issued_book.issue_date).days - 3
        if days_overdue > 0:
            penalty_amount = days_overdue * 50

    return render(request, 'account/return_book_confirm.html', {
        'book': issued_book.book,
        'issue_id': issue_id,
        'user': user,
        'issued_book': issued_book,
        'penalty_amount': penalty_amount,
        'days_overdue': days_overdue,
    })

@login_required_custom
def penalty_list(request):
    user = get_logged_in_user(request)
    if not user:
        return redirect('login')
    
    penalties = Penalty.objects.filter(user=user).order_by('-created_at')
    
    # Calculate statistics
    total_amount = sum(penalty.fine_amount for penalty in penalties)
    paid_count = penalties.filter(is_paid=True).count()
    unpaid_count = penalties.filter(is_paid=False).count()
    
    return render(request, 'account/penalty_list.html', {
        'penalties': penalties,
        'user': user,
        'total_amount': total_amount,
        'paid_count': paid_count,
        'unpaid_count': unpaid_count,
    })

@login_required_custom
def pay_penalty(request, penalty_id):
    user = get_logged_in_user(request)
    if not user:
        return redirect('login')
    
    penalty = get_object_or_404(Penalty, id=penalty_id, user=user)
    
    if request.method == 'POST':
        penalty.is_paid = True
        penalty.save()
        messages.success(request, f"Penalty of ₹{penalty.fine_amount} has been paid successfully.")
        return redirect('penalty_list')
    
    return render(request, 'account/pay_penalty.html', {
        'penalty': penalty,
        'user': user,
    })

@login_required_custom
def history(request):
    user = get_logged_in_user(request)
    if not user:
        return redirect('login')
    
    histories = History.objects.filter(user=user)
    
    # Calculate statistics
    total_books = histories.count()
    total_days = sum(history.days_borrowed for history in histories)
    books_with_penalties = histories.filter(had_penalty=True).count()
    total_penalty_paid = sum(history.penalty_amount for history in histories if history.had_penalty)
    
    return render(request, 'account/history.html', {
        'histories': histories,
        'user': user,
        'total_books': total_books,
        'total_days': total_days,
        'books_with_penalties': books_with_penalties,
        'total_penalty_paid': total_penalty_paid,
    })
