function addCart(){
    confirm("Product added to cart")
}