function login_form(){
    var usernameValidation = document.getElementById("login-username").value;
    var passwordValidation = document.getElementById("login-password").value;
    pat = /^[A-Za-z]+$/ ;
    pat2 = /^(?=.*[\W_]).+$/;
    if (passwordValidation.length >= 8) {
        alert("Password length should be less than 8");
        document.getElementById("login-password").value = "";
    }
    else{
        if (pat.test(usernameValidation) && pat2.test(passwordValidation)) {
            alert("Login Successful");
        } else {
            alert("Enter valid username and password");
            document.getElementById("login-username").value = "";
            document.getElementById("login-password").value = "";
        }
    }
}

function register_form(){
    var usernameValidation = document.getElementById("register-username").value;
    var passwordValidation = document.getElementById("register-password").value;
    var confirmPasswordValidation = document.getElementById("register-password2").value;
    pat = /^[A-Za-z]+$/ ;
    pat2 = /^(?=.*[\W_]).+$/;
    if (passwordValidation.length >= 8) {
        alert("Password length should be less than 8");
        document.getElementById("register-password").value = "";  //clearing the password field
        document.getElementById("register-password2").value = ""; //clearing the confirm password field 
    }
    else{
        if(confirmPasswordValidation != passwordValidation){
            alert("Password and Confirm Password should be same");
            document.getElementById("register-password").value = ""; //clearing the password field
            document.getElementById("register-password2").value = "";
        }
        else{
            if (pat.test(usernameValidation) && pat2.test(passwordValidation)) {
                alert("Registration Successful");
            } else {
                alert("Enter valid username and password");
                document.getElementById("register-username").value = "";
                document.getElementById("register-password").value = "";
                document.getElementById("register-password2").value = "";
            }
        }
    }
}