package Main;

import java.util.Scanner;
import LinkList_Package.LL;
import SBS.StoreBillingSystem;
import java.sql.*;


class Main {
    public static void main(String[] args) throws Exception {
        Scanner sc = new Scanner(System.in);
        LL linkedList = new LL();
        StoreBillingSystem storeBillingSystem = null;

        String dburl = "jdbc:mysql://localhost:3306/StoreBillingSystem";
        String dbuser = "root";
        String dbpassword = "";
        String driverName = "com.mysql.cj.jdbc.Driver";
        Class.forName(driverName);
        Connection con = DriverManager.getConnection(dburl, dbuser, dbpassword); ;
        if (con != null) {
            System.out.println("Database is connected successfully\n");
        } else {
            System.out.println("Database is not connected successfully");
        }
        
        int productId;
        String productName;
        float price;
        int quantity;
        float discount;
        float gst;
        float totalPrice;
        String choice = "n";
        int counter = 1;
        float totalGST = 0;
        float totalDiscount = 0;
        float totalAmount = 0;

        System.out.print("Enter the Name of Customer :");
        String name = sc.nextLine();
        System.out.print("Enter the Phone Number of Customer :");
        long phoneNumber = sc.nextLong();
        sc.nextLine();
        if (phoneNumber / 1000000000 == 0) {
            System.out.println("Enter Valied Number");
            sc.close();
            return;
        }
        String sql = "INSERT INTO Customer (CustomerName,CustomerNumber) VALUES (?,?)" ;
        PreparedStatement pst = con.prepareStatement(sql);
        pst.setString(1, name); 
        pst.setLong(2, phoneNumber);
        pst.executeUpdate();

        do {
            System.out.println("---------------------------------");
            System.out.println(" Enter " + counter + " Product Details");
            System.out.println("---------------------------------");
            
            try {
                System.out.print("Enter productId: ");
                productId = sc.nextInt();
                sc.nextLine();
                
                System.out.print("Enter Product Name :");
                productName = sc.nextLine();
                
                System.out.print("Enter Product Price :");
                price = sc.nextFloat();
                
                System.out.print("Enter Product Quantity :");
                quantity = sc.nextInt();
                
                System.out.print("Enter Discount (%) :");
                discount = sc.nextFloat();
                
                System.out.print("Enter SGST/CGST (%) :");
                gst = sc.nextFloat();

                // Calculate discount and GST
                float discountAmount = (discount * price * quantity) / 100;
                float gstAmount = (gst * price * quantity) / 100;

                // Calculate total price
                totalPrice = ((price * quantity) - discountAmount) + gstAmount;

                totalDiscount += discountAmount;
                totalGST += gstAmount;
                totalAmount += totalPrice;

                storeBillingSystem = new StoreBillingSystem(productId, productName, price, quantity, discountAmount, gstAmount, totalPrice);
                linkedList.add(storeBillingSystem);
                
                String sql1 = "INSERT INTO Product (customerName, customerNumber, productId, productName, price, quantity, discount, gst, totalPrice) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
                try (PreparedStatement pst1 = con.prepareStatement(sql1)) {
                    pst1.setString(1, name);
                    pst1.setLong(2, phoneNumber);
                    pst1.setInt(3, productId);
                    pst1.setString(4, productName);
                    pst1.setFloat(5, price);
                    pst1.setInt(6, quantity);
                    pst1.setFloat(7, discountAmount);
                    pst1.setFloat(8, gstAmount);
                    pst1.setFloat(9, totalPrice);
                    pst1.executeUpdate();
                } catch (SQLException e) {
                    System.out.println("Data is not inserted successfully");
                    e.printStackTrace();
                }
                
                counter++;
                sc.nextLine(); // Consume leftover newline
                System.out.print("Do you want to add more items (Y/N): ");
                choice = sc.nextLine();
            } catch (Exception e) {
                System.out.println("Invalid input. Please enter valid data.");
                sc.nextLine(); 
                choice = "Y"; 
            }
        } while (choice.equalsIgnoreCase("y"));

        System.out.println("\n\t\t\t\t-------------Invoice------------");
        System.out.println("\t\t\t\t    Dmart Supermarket Shop");
        System.out.println("\t\t\t\t Near GoldenSquare Surat, Gujarat");
        System.out.println("\t\t\t\t    Opposite ShaliBhadra");
        System.out.println("GSTIN: 03AWBPP8756K592\t\t\t\t\t\t\t\t\t\tContact: (+91) 8487804512");
        System.out.println("------------------------------------------------------------------------------------------------------------------------");
        System.out.println("Customer Name: " + name + "\t\t\t\t\t\t\t\t\t\tPhone Number: " + phoneNumber);
        System.out.println("------------------------------------------------------------------------------------------------------------------------");

        // Display the formatted invoice
        storeBillingSystem.displayFormate();
        // Display the detaills of product
        for (StoreBillingSystem sbs : linkedList) {
            sbs.diplay(); 
        }

        System.out.println("\t\t\t\t\t\t\t\t\t\t\t\tTotal GST: " + totalGST);
        System.out.println("\t\t\t\t\t\t\t\t\t\t\t\tTotal Discount: " + totalDiscount);
        System.out.println("\t\t\t\t\t\t\t\t\t\t\t\tTotal Amount: " + totalAmount);
        System.out.println("\t\t\t\t----------------Thank You for Shopping!!-----------------");
        System.out.println("\t\t\t\t                     Visit Again");

        String paymentType ;
        String sql2 = "INSERT INTO PAYMENT (CustomerName , CustomerNumber , Date , paymentType ,TotalAmount ) VALUES(?,?,?,?,?)" ;
        PreparedStatement pst2 = con.prepareStatement(sql2);
        System.out.println("Press 1 for cash");
        System.out.println("Press 2 for Onlien");
        System.out.print("Enter your payment Choise :");
        int paymentChoise = sc.nextInt();
        switch (paymentChoise) {
            case 1:
                    paymentType = "Cash" ;
                    float billAmount = totalAmount ;
                    System.out.println("Total Bill :"+billAmount);
                    int numberOf500$Note = +(int)(billAmount/500);
                    if (numberOf500$Note>0) {
                        System.out.println("Number of 500$ Note is :"+numberOf500$Note);
                        billAmount %= 500 ; 
                    } 
                    int numberOf200$Note = +(int)(billAmount/200);
                    if(numberOf200$Note>0) {
                        System.out.println("Number of 200$ Note is : "+numberOf200$Note);
                        billAmount %= 200 ; 
                    } 
                    int numberOf100$Note = +(int)(billAmount/100);
                    if (numberOf100$Note>0) {
                        System.out.println("Number of 100$ Note is : "+numberOf100$Note);
                        billAmount %= 100 ; 
                    } 
                    int numberOf50$Note = +(int)(billAmount/50);
                    if (numberOf50$Note>0) {
                        System.out.println("Number of 50$ Note is : "+numberOf50$Note);
                        billAmount %= 50 ; 
                    } 
                    int numberOf20$Note = +(int)(billAmount/20);
                    if (numberOf20$Note>0) {
                        System.out.println("Number of 20$ Note is : "+numberOf20$Note);
                        billAmount %= 20 ; 
                    } 
                    int numberOf10$Note = +(int)(billAmount/10);
                    if (numberOf10$Note>0) {
                        System.out.println("Number of 10$ Note is : "+numberOf10$Note);
                        billAmount %= 10 ; 
                    } 
                    int numberOf5$Note = +(int)(billAmount/5);
                    if (numberOf5$Note>0) {
                        System.out.println("Number of 5$ Note is : "+numberOf5$Note);
                        billAmount %= 5 ; 
                    } 
                    int numberOf2$Note = +(int)(billAmount/2);
                    if (numberOf2$Note>0) {
                        System.out.println("Number of 2$ Note is : "+numberOf2$Note);
                        billAmount %= 2 ; 
                    }
                    int numberOf1$Note = +(int)(billAmount/1);
                    if (numberOf1$Note>0) {
                        System.out.println("Number of 1$ Note is : "+numberOf1$Note);
                        billAmount %= 1 ; 
                    }  
                    pst2.setString(1, name);
                    pst2.setLong(2, phoneNumber);
                    pst2.setDate(3, new java.sql.Date(System.currentTimeMillis()));
                    pst2.setString(4, paymentType);
                    pst2.setFloat(5, totalAmount);
                    pst2.executeUpdate();
                    System.out.println("Payment Done...!");
                break ;    
            case 2 :    
                    paymentType = "Onlien" ;
                    System.out.println("\t\t\t\t\t\t\t\tScann this QR ");
                    System.out.println("BillAmount :"+totalAmount);
                    for (int i = 1; i < 8; i++) {
                        for (int j = 1; j < 8; j++) {
                            System.out.print("* ");
                        }
                        System.out.println();
                    }
                    int count = 0 ;
                    int attempt = 3 ;
                    do {
                        System.out.print("Enter your Pin :");
                        int pin = sc.nextInt();
                        while (pin!=0) {
                            pin = pin/10 ;
                            count++ ;
                        }
                        if (count==4 || count==6) {
                            pst2.setString(1, name);
                            pst2.setLong(2, phoneNumber);
                            pst2.setDate(3, new java.sql.Date(System.currentTimeMillis()));
                            pst2.setString(4, paymentType);
                            pst2.setFloat(5, totalAmount);
                            pst2.executeUpdate();
                            System.out.println("Payment Done....!");
                            break ;
                        }
                        else{
                            System.out.println("Enter Valied Pin");
                            attempt-- ;
                        }
                    } while (attempt!=0);
                break ;
        }

        sc.close();
        //con.close();
    }
}
