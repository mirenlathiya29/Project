package SBS;

public class StoreBillingSystem{
    public int productId ; 
    public String productName ;
    public float price ;
    public int quantity ;
    public float discount ;
    public float gst ;
    public float totalPrice ;
    public StoreBillingSystem(int productId ,String productName, float price , int quantity , float discount , float gst , float totalPrice){
        this.productId = productId ;
        this.productName = productName ;
        this.price = price ;
        this.quantity = quantity ;
        this.discount = discount ;
        this.gst = gst ;
        this.totalPrice = totalPrice;
    }
    public int getproductId(){
        return productId ;
    }
    public String getProductName(){
        return productName ;
    }
    public float getPrice(){
        return price ;
    } 
    public int getQuantity(){
        return quantity ;
    }
    public float getDiscount(){
        return discount ;
    }
    public float getGst(){
        return gst ;
    }
    public float gettotalPrice(){
        return totalPrice ;
    }
    public void displayFormate(){
        System.out.println("------------------------------------------------------------------------------------------------------------------------");
        System.out.println("     productId    |     ProductName     |     Price     |     Quntity     |     Discount     |     GST     |     TotalPrice     |");
    }
    public void diplay(){
        System.out.println("     "+productId+"     |"+"     "+productName+"     |"+"     "+price+"     |"+"     "+quantity+"     |"+"     "+discount+"     |"+"     "+gst+"     |"+"     "+totalPrice+"     |"); 
        System.out.println();
    }
}
