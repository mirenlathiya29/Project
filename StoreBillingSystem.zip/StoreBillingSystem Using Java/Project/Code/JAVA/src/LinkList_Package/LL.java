package LinkList_Package ;
import java.util.Iterator;
import java.util.NoSuchElementException;
import SBS.*;

// Assuming LL is a custom linked list class
public class LL implements Iterable<StoreBillingSystem> {

    private Node head;
    private int size;

    // Node class for the linked list
    private static class Node {
        StoreBillingSystem data;
        Node next;

        Node(StoreBillingSystem data, Node next) {
            this.data = data;
            this.next = next;
        }
    }

    // Constructor
    public LL() {
        head = null;
        size = 0;
    }

    // Add method to add elements to the linked list
    public void add(StoreBillingSystem data) {
        head = new Node(data, head);
        size++;
    }

    // Implementing Iterable interface
    @Override
    public Iterator<StoreBillingSystem> iterator() {
        return new Iterator<StoreBillingSystem>() {
            private Node current = head;

            @Override
            public boolean hasNext() {
                return current != null;
            }

            @Override
            public StoreBillingSystem next() {
                if (!hasNext()) {
                    throw new NoSuchElementException();
                }
                StoreBillingSystem data = current.data;
                current = current.next;
                return data;
            }
        };
    }

    // Optional: Implement size() method for convenience
    public int size() {
        return size;
    }
}
